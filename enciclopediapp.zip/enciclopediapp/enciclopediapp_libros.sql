CREATE DATABASE  IF NOT EXISTS `enciclopediapp` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;
USE `enciclopediapp`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: enciclopediapp
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `libros`
--

DROP TABLE IF EXISTS `libros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `libros` (
  `idlibros` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `categoria` varchar(45) NOT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `editorial` varchar(45) NOT NULL,
  `fch_publi` varchar(45) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idlibros`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libros`
--

LOCK TABLES `libros` WRITE;
/*!40000 ALTER TABLE `libros` DISABLE KEYS */;
INSERT INTO `libros` VALUES (1,'Cien años de soledad','Acción y Aventura','Cherokee Stafford','Dictum Corp.','2002-05-09',NULL),(2,'1984','Clásico','Octavius Levy','Libero Et Tristique Industries','2018-03-30',NULL),(3,'Matar a un ruiseñor','Clásico','Basia Bernard','Dolor Nonummy Ac Incorporated','2019-07-29',NULL),(4,'El gran Gatsby','Clásico','Leandra Fisher','Fringilla Ltd','1993-11-02',NULL),(5,'En busca del tiempo perdido','Acción y Aventura','Hammett Chen','Nulla At Corp.','2014-09-05',NULL),(6,'Ulises','Romance','Venus Dodson','Fermentum Corp.','2017-02-25',NULL),(7,'Lolita','Acción y Aventura','Elizabeth Caldwell','Diam Sed Consulting','2022-01-21',NULL),(8,'Crimen y castigo','Romance','Dalton Rowe','Urna Nec Limited','2021-11-21',NULL),(9,'Guerra y paz','Fantasía','Nelle Logan','Euismod Mauris Ltd','2012-04-08',NULL),(10,'La Odisea','Suspenso','Quon Roberson','Mi Lorem Vehicula LLC','2011-01-05',NULL),(11,'Don Quijote de la Mancha','Historia','Gavin Simpson','Nec Mollis Incorporated','2002-09-16',NULL),(12,'Orgullo y prejuicio','Horror','Cameran Murphy','Risus Donec Consulting','1990-11-26',NULL),(13,'Moby Dick','Romance','McKenzie Spence','Accumsan Corporation','1998-11-24',NULL),(14,'El señor de los anillos','Cómic','Nissim Stout','Imperdiet Ullamcorper Limited','1998-10-20',NULL),(15,'El principito','Acción y Aventura','Cynthia Heath','Lorem Eu LLP','2010-04-14',NULL);
/*!40000 ALTER TABLE `libros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-03 10:47:58
