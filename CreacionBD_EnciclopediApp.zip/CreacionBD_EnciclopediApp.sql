-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema enciclopediapp
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema enciclopediapp
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `enciclopediapp` DEFAULT CHARACTER SET utf8 ;
USE `enciclopediapp` ;

-- -----------------------------------------------------
-- Table `enciclopediapp`.`clientes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`clientes` (
  `idclientes` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `fch_nac` DATE NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  `telefono` VARCHAR(45) NULL,
  `password` VARCHAR(45) NOT NULL,
  `afiliado` TINYINT NOT NULL,
  `acept_publi` TINYINT NOT NULL,
  PRIMARY KEY (`idclientes`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `enciclopediapp`.`empleados`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`empleados` (
  `idempleados` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `fch_nac` DATE NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  `telefono` VARCHAR(45) NULL,
  `puesto` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idempleados`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `enciclopediapp`.`valoraciones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`valoraciones` (
  `idvaloraciones` INT NOT NULL AUTO_INCREMENT,
  `puntaje` INT NOT NULL,
  `recomendado` TINYINT NOT NULL,
  `comentario` VARCHAR(300) NULL,
  `fch_publi` DATE NOT NULL,
  `clientes_idclientes` INT NOT NULL,
  PRIMARY KEY (`idvaloraciones`, `clientes_idclientes`),
  CONSTRAINT `fk_valoraciones_clientes1`
    FOREIGN KEY (`clientes_idclientes`)
    REFERENCES `enciclopediapp`.`clientes` (`idclientes`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `enciclopediapp`.`libros`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`libros` (
  `idlibros` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `categoria` VARCHAR(45) NOT NULL,
  `autor` VARCHAR(45) NULL,
  `editorial` VARCHAR(45) NOT NULL,
  `fch_publi` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idlibros`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `enciclopediapp`.`pedidos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`pedidos` (
  `idpedidos` INT NOT NULL AUTO_INCREMENT,
  `contenido` VARCHAR(45) NOT NULL,
  `fch_compra` DATE NOT NULL,
  `total_precio` DOUBLE NOT NULL,
  PRIMARY KEY (`idpedidos`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `enciclopediapp`.`clientes_has_pedidos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`clientes_has_pedidos` (
  `clientes_idclientes` INT NOT NULL,
  `pedidos_idpedidos` INT NOT NULL,
  PRIMARY KEY (`clientes_idclientes`, `pedidos_idpedidos`),
  CONSTRAINT `fk_clientes_has_pedidos_clientes`
    FOREIGN KEY (`clientes_idclientes`)
    REFERENCES `enciclopediapp`.`clientes` (`idclientes`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_clientes_has_pedidos_pedidos1`
    FOREIGN KEY (`pedidos_idpedidos`)
    REFERENCES `enciclopediapp`.`pedidos` (`idpedidos`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `enciclopediapp`.`pedidos_has_libros`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`pedidos_has_libros` (
  `pedidos_idpedidos` INT NOT NULL,
  `libros_idlibros` INT NOT NULL,
  PRIMARY KEY (`pedidos_idpedidos`, `libros_idlibros`),
  CONSTRAINT `fk_pedidos_has_libros_pedidos1`
    FOREIGN KEY (`pedidos_idpedidos`)
    REFERENCES `enciclopediapp`.`pedidos` (`idpedidos`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_pedidos_has_libros_libros1`
    FOREIGN KEY (`libros_idlibros`)
    REFERENCES `enciclopediapp`.`libros` (`idlibros`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `enciclopediapp`.`libros_has_valoraciones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`libros_has_valoraciones` (
  `libros_idlibros` INT NOT NULL,
  `valoraciones_idvaloraciones` INT NOT NULL,
  PRIMARY KEY (`libros_idlibros`, `valoraciones_idvaloraciones`),
  CONSTRAINT `fk_libros_has_valoraciones_libros1`
    FOREIGN KEY (`libros_idlibros`)
    REFERENCES `enciclopediapp`.`libros` (`idlibros`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_libros_has_valoraciones_valoraciones1`
    FOREIGN KEY (`valoraciones_idvaloraciones`)
    REFERENCES `enciclopediapp`.`valoraciones` (`idvaloraciones`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `enciclopediapp`.`empleados_has_clientes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `enciclopediapp`.`empleados_has_clientes` (
  `empleados_idempleados` INT NOT NULL,
  `clientes_idclientes` INT NOT NULL,
  PRIMARY KEY (`empleados_idempleados`, `clientes_idclientes`),
  CONSTRAINT `fk_empleados_has_clientes_empleados1`
    FOREIGN KEY (`empleados_idempleados`)
    REFERENCES `enciclopediapp`.`empleados` (`idempleados`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_empleados_has_clientes_clientes1`
    FOREIGN KEY (`clientes_idclientes`)
    REFERENCES `enciclopediapp`.`clientes` (`idclientes`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
