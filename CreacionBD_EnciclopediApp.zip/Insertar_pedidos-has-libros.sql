INSERT INTO `pedidos_has_libros` (`pedidos_idpedidos`,`libros_idlibros`)
VALUES
  (3,10),
  (3,2),
  (4,13),
  (2,5),
  (4,3),
  (3,14),
  (3,4),
  (2,9);

INSERT INTO `pedidos_has_libros` (`pedidos_idpedidos`,`libros_idlibros`)
VALUES
  (3,5),
  (4,2),
  (5,6),
  (1,13),
  (4,6);
