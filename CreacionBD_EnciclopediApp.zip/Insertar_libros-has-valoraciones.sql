INSERT INTO `libros_has_valoraciones` (`libros_idlibros`,`valoraciones_idvaloraciones`)
VALUES
  (7,1),
  (14,11),
  (5,19),
  (10,22),
  (2,9),
  (2,2),
  (1,1),
  (13,16),
  (5,9),
  (2,23);
INSERT INTO `libros_has_valoraciones` (`libros_idlibros`,`valoraciones_idvaloraciones`)
VALUES
  (5,14),
  (9,24),
  (14,4),
  (9,17),
  (15,8);