INSERT INTO `pedidos` (`contenido`,`fch_compra`,`total_precio`)
VALUES
  ("En busca del tiempo perdido, Orgullo y prejuicio, Cien años de soledad, Guerra y paz","2024-02-20","12.88"),
  ("La Odisea, Moby Dick, 1984, En busca del tiempo perdido","2024-04-07","24.03"),
  ("Orgullo y prejuicio, Don Quijote de la Mancha, Guerra y paz, Matar a un ruiseñor","2024-04-17","13.20"),
  ("El principito, Moby Dick, Ulises, Guerra y paz","2024-01-30","8.90"),
  ("El señor de los anillos, Cien años de soledad, En busca del tiempo perdido","2024-03-13","18.04");