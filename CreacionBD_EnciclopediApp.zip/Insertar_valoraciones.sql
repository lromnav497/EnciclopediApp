INSERT INTO `valoraciones` (`puntaje`,`recomendado`,`comentario`,`fch_publi`,`clientes_idclientes`)
VALUES
  (3,"0","Sed et libero. Proin mi. Aliquam","2017-07-03",7),
  (1,"0","orci, adipiscing non, luctus sit amet, faucibus ut, nulla. Cras eu tellus eu augue porttitor interdum. Sed auctor odio","2016-03-16",8),
  (3,"1","nisi. Aenean eget metus.","2018-08-31",21),
  (5,"1","sagittis placerat. Cras","2020-06-22",33),
  (0,"1","mattis velit justo nec ante. Maecenas mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate,","2023-01-08",44),
  (3,"1","Suspendisse non leo. Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc,","2017-01-11",19),
  (2,"0","a purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis est, vitae sodales nisi magna","2018-07-13",20),
  (4,"1","sit amet luctus vulputate, nisi sem semper erat, in consectetuer ipsum nunc id enim.","2022-12-07",36),
  (4,"0","nunc. In at pede. Cras vulputate velit eu sem. Pellentesque ut ipsum ac mi eleifend egestas. Sed","2020-09-25",32),
  (3,"1","Duis elementum, dui quis accumsan convallis,","2019-05-05",40);
INSERT INTO `valoraciones` (`puntaje`,`recomendado`,`comentario`,`fch_publi`,`clientes_idclientes`)
VALUES
  (2,"0","urna. Ut tincidunt vehicula risus. Nulla eget metus eu erat semper rutrum. Fusce dolor quam,","2015-03-09",12),
  (1,"0","Donec feugiat metus sit amet ante. Vivamus","2023-01-26",9),
  (4,"1","sem molestie sodales. Mauris blandit enim consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio.","2018-12-06",23),
  (5,"0","neque. In ornare sagittis felis. Donec tempor, est ac","2019-04-27",8),
  (5,"1","leo elementum sem,","2017-04-24",38),
  (1,"1","ante. Maecenas mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum.","2017-08-17",41),
  (5,"0","lobortis augue","2021-07-11",12),
  (5,"1","Nunc quis arcu vel quam dignissim pharetra. Nam ac nulla. In tincidunt congue turpis. In","2022-09-14",18),
  (3,"0","lacinia at, iaculis","2018-04-29",36),
  (1,"0","pharetra nibh. Aliquam ornare, libero at auctor","2020-09-21",46);
INSERT INTO `valoraciones` (`puntaje`,`recomendado`,`comentario`,`fch_publi`,`clientes_idclientes`)
VALUES
  (2,"0","id risus quis diam luctus lobortis.","2017-02-12",21),
  (3,"1","Donec egestas. Duis ac arcu. Nunc mauris. Morbi","2022-04-06",46),
  (2,"1","pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin","2019-01-21",36),
  (2,"1","In lorem. Donec elementum, lorem ut aliquam iaculis, lacus","2017-06-16",8),
  (3,"0","cubilia Curae Phasellus ornare. Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem,","2020-01-29",23);
