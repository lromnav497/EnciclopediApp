INSERT INTO `clientes_has_pedidos` (`clientes_idclientes`,`pedidos_idpedidos`)
VALUES
  (23,5),
  (23,2),
  (3,3),
  (40,1),
  (32,4);