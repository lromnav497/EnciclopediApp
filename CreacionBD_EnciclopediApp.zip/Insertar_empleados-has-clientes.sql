INSERT INTO `empleados_has_clientes` (`empleados_idempleados`,`clientes_idclientes`)
VALUES
  (1,14), 
  (2,48), 
  (8,30), 
  (4,42), 
  (9,23), 
  (6,17), 
  (2,49), 
  (6,46), 
  (9,5), 
  (2,30);
INSERT INTO `empleados_has_clientes` (`empleados_idempleados`,`clientes_idclientes`)
VALUES
  (7,47),
  (7,31),
  (2,46),
  (7,22);
