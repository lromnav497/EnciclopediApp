INSERT INTO `empleados` (`nombre`,`apellido`,`fch_nac`,`correo`,`telefono`,`password`,`puesto`)
VALUES
  ("Charde","Mills","09-05-95","justo.praesent@hotmail.edu","529 83 66 11","KCS01ETT4JW","Administrador"),
  ("Whitney","Jimenez","29-12-96","in.condimentum@icloud.net","472 23 95 29","VOG67OXL1IQ","Gestor"),
  ("Clio","Dale","07-11-97","nunc@google.edu","578 94 16 41","VOU70ICY4OU","Administrador"),
  ("Nina","Hull","12-03-99","pede@icloud.ca","426 77 47 86","YMF37LOF3KO","Soporte"),
  ("Aimee","Morgan","29-06-95","purus@yahoo.edu","417 62 21 36","XEB57DRJ3XJ","Gerente"),
  ("Celeste","Madden","21-01-02","fermentum.metus@outlook.net","815 44 03 98","RSK91FQV5GG","Gestor"),
  ("Keane","Cabrera","12-09-00","pretium.et.rutrum@icloud.edu","489 75 17 13","KOJ64YXH7LJ","Soporte"),
  ("George","York","24-01-04","nibh.phasellus@icloud.couk","274 70 63 44","DOK14YEY2GX","Soporte"),
  ("Anthony","Chen","05-04-05","nec.enim.nunc@yahoo.com","597 57 75 78","CUQ80LJO3EN","Soporte"),
  ("India","Kane","20-11-03","dui@aol.couk","924 61 16 66","RCJ69XGI5VX","Soporte");
