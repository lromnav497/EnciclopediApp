INSERT INTO `libros` (`nombre`,`categoria`,`autor`,`editorial`,`fch_publi`)
VALUES
  ("Cien años de soledad","Acción y Aventura","Cherokee Stafford","Dictum Corp.","2002-05-09"),
  ("1984","Clásico","Octavius Levy","Libero Et Tristique Industries","2018-03-30"),
  ("Matar a un ruiseñor","Clásico","Basia Bernard","Dolor Nonummy Ac Incorporated","2019-07-29"),
  ("El gran Gatsby","Clásico","Leandra Fisher","Fringilla Ltd","1993-11-02"),
  ("En busca del tiempo perdido","Acción y Aventura","Hammett Chen","Nulla At Corp.","2014-09-05"),
  ("Ulises","Romance","Venus Dodson","Fermentum Corp.","2017-02-25"),
  ("Lolita","Acción y Aventura","Elizabeth Caldwell","Diam Sed Consulting","2022-01-21"),
  ("Crimen y castigo","Romance","Dalton Rowe","Urna Nec Limited","2021-11-21"),
  ("Guerra y paz","Fantasía","Nelle Logan","Euismod Mauris Ltd","2012-04-08"),
  ("La Odisea","Suspenso","Quon Roberson","Mi Lorem Vehicula LLC","2011-01-05");
INSERT INTO `libros` (`nombre`,`categoria`,`autor`,`editorial`,`fch_publi`)
VALUES
  ("Don Quijote de la Mancha","Historia","Gavin Simpson","Nec Mollis Incorporated","2002-09-16"),
  ("Orgullo y prejuicio","Horror","Cameran Murphy","Risus Donec Consulting","1990-11-26"),
  ("Moby Dick","Romance","McKenzie Spence","Accumsan Corporation","1998-11-24"),
  ("El señor de los anillos","Cómic","Nissim Stout","Imperdiet Ullamcorper Limited","1998-10-20"),
  ("El principito","Acción y Aventura","Cynthia Heath","Lorem Eu LLP","2010-04-14");